// Bấm gửi một lần sau khi người dùng xác minh CAPTCHA trong tab này.
// Chỉ trả trạng thái, không đưa giá trị CAPTCHA ra ngoài trang.
(() => {
  const result = (state, message) => JSON.stringify({ state, message });
  if (location.protocol !== 'https:' || location.hostname !== 'treemvietnam.net.vn'
    || location.pathname !== '/truong-hoc-hanh-phuc/truong-tieu-hoc-thinh-liet-1098.html') {
    return result('error', 'Tab không còn ở trang Trường Tiểu học Thịnh Liệt.');
  }
  if (window.__thinhLietVoteClicked) {
    return result('clicked', 'Nút bình chọn đã được bấm; không bấm lại.');
  }
  const popup = document.querySelector('#vote-popup');
  if (!popup || !popup.getClientRects().length || getComputedStyle(popup).visibility === 'hidden') {
    return result('error', 'Biểu mẫu bình chọn đã đóng.');
  }
  const button = popup.querySelector('#btn-confirm-vote');
  const ratings = [...popup.querySelectorAll('select.rating')];
  if (button?.getAttribute('data-thhp_id') !== '1098'
    || popup.querySelectorAll('.rating-wrapper').length !== 8
    || ratings.length !== 8 || ratings.some(select => select.value !== '5')) {
    return result('error', 'Biểu mẫu phải đúng trường Thịnh Liệt và đủ tám mục 5 sao.');
  }
  const remaining = popup.querySelector('#err-max-vote')?.textContent.trim();
  if (!/^\d+$/.test(remaining ?? '')) {
    return result('error', 'Không xác định được số lượt bình chọn còn lại.');
  }
  if (Number(remaining) === 0) {
    return result('error', 'Đã hết lượt bình chọn trên trang.');
  }
  if (!popup.querySelector('[name="cf-turnstile-response"]')?.value.trim()) {
    return result('waiting', 'Đang chờ bạn xác minh CAPTCHA.');
  }
  if (button.disabled || button.getAttribute('aria-disabled') === 'true'
    || !button.getClientRects().length || getComputedStyle(button).visibility === 'hidden') {
    return result('waiting', 'Đang chờ nút bình chọn sẵn sàng.');
  }
  // Đánh dấu trước khi bấm để các lần kiểm tra tiếp theo không gửi lại.
  window.__thinhLietVoteClicked = true;
  button.click();
  return result('clicked', 'Đã bấm Bình chọn ngay một lần. Hãy kiểm tra kết quả trên trang.');
})()
